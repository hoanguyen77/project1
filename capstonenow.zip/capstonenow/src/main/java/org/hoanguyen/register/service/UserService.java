package org.hoanguyen.register.service;


import org.hoanguyen.register.dto.UserDTO;
import org.hoanguyen.register.entity.User;
import org.hoanguyen.register.exception.UserExistException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;


public interface UserService extends UserDetailsService {

  public UserDetails loadUserByUsername (String username);

    public void saveUser(UserDTO userDTO) throws UserExistException ;
    public User findUserByEmailForSecurity(String email);

    public User findUserByEmail(String email) throws UserExistException;
}
package org.hoanguyen.register.repository;

import org.hoanguyen.register.entity.Member;
import org.hoanguyen.register.entity.Senior;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SeniorRepository extends CrudRepository<Senior, Integer> {
    public Optional<Senior> findSeniorByEmail (String email);
//    @Query(value = "from Senior where lastName like %:name%")
//    public List<Senior> findSeniorsByLastNameLike(@Param(value = "name") String name);
    }


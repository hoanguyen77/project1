package org.hoanguyen.register.service;

import jakarta.transaction.Transactional;
import org.hoanguyen.register.dto.AccountDTO;
import org.hoanguyen.register.dto.MemberDTO;
import org.hoanguyen.register.dto.SeniorDTO;
import org.hoanguyen.register.entity.Account;
import org.hoanguyen.register.entity.Member;
import org.hoanguyen.register.entity.Senior;
import org.hoanguyen.register.exception.UserExistException;
import org.hoanguyen.register.repository.AccountRepository;
import org.hoanguyen.register.repository.SeniorRepository;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class SeniorServiceImpl implements SeniorService{
    private static final Logger logger = LoggerFactory.getLogger(SeniorServiceImpl.class.getName());

    private SeniorRepository seniorRepository;


    @Autowired
    public SeniorServiceImpl(SeniorRepository seniorRepository) {
        this.seniorRepository = seniorRepository;

    }





    @Override
    @Transactional
    public void saveSenior(SeniorDTO seniorDTO) throws UserExistException {
        Optional<Senior> optionalSenior = seniorRepository.findSeniorByEmail(seniorDTO.getEmail());

        if(optionalSenior.isPresent()) {
            throw new RuntimeException("Senior already exist");
        }else {
            ModelMapper modelMapper = new ModelMapper();
            modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
            Senior senior = modelMapper.map(seniorDTO, Senior.class);

           seniorRepository.save(senior);
        }

    }


    @Override
    @Transactional
    public SeniorDTO findSeniorByEmail(String email) {
        Optional<Senior>seniorOptional = seniorRepository.findSeniorByEmail(email);
        if(seniorOptional.isPresent()){
            ModelMapper modelMapper = new ModelMapper();
            modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
            SeniorDTO seniorDTO = modelMapper.map(seniorOptional.get(), SeniorDTO.class);
            return seniorDTO;
        }
        else
            throw new UsernameNotFoundException("User Not Found");
    }

    @Override
    @Transactional
    public List<SeniorDTO> getAllSeniors() {
        List<SeniorDTO> seniorDTOS = new ArrayList<>();

        for(Senior senior : seniorRepository.findAll())
        {
            ModelMapper modelMapper = new ModelMapper();
            modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
            SeniorDTO seniorDTO = modelMapper.map(senior, SeniorDTO.class);

            seniorDTOS.add(seniorDTO);
        }
        return seniorDTOS;

}}
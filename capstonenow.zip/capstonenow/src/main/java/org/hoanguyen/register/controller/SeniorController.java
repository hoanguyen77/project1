package org.hoanguyen.register.controller;

import jakarta.validation.Valid;
import org.hoanguyen.register.dto.AccountDTO;
import org.hoanguyen.register.dto.SeniorDTO;
import org.hoanguyen.register.dto.UserDTO;
import org.hoanguyen.register.exception.UserExistException;
import org.hoanguyen.register.service.AccountService;
import org.hoanguyen.register.service.SeniorService;
import org.hoanguyen.register.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Arrays;
import java.util.UUID;

@Controller
public class SeniorController {
    private static final Logger logger = LoggerFactory.getLogger(SeniorController.class.getName());
    @Autowired
    private SeniorService seniorService;

    private UserService userService;

    @Autowired
    public SeniorController(SeniorService seniorService, UserService userService) {
        this.seniorService = seniorService;
        this.userService = userService;
    }



    @GetMapping("/senior-sign-up")
    public String seniorForm(Model model){
        model.addAttribute("senior", new SeniorDTO());
        model.addAttribute("user", new UserDTO());
        return "senior-sign-up";
    }
    @PostMapping("/process-senior")
    public String processingSenior(@Valid @ModelAttribute("senior")
                                   SeniorDTO seniorDTO, BindingResult seniorBindingResult,
                                   @Valid @ModelAttribute ("user") UserDTO userDTO,
                                   BindingResult userBindingResult,
                                   Model model) {

        if (userBindingResult.hasErrors()) {
            return "senior-sign-up";
        }
        try {
            seniorService.saveSenior(seniorDTO);
            userDTO.setEmail(seniorDTO.getEmail());
            userDTO.setRole("ROLE_SENIOR");
            userService.saveUser(userDTO);
        } catch (Exception e) {
            model.addAttribute("message", "Senior exist");
            return "senior-sign-up";
        }

            return "redirect:/success";

    }
    @GetMapping("/all-seniors")
    public String listOfSeniors(Model model){

        model.addAttribute("seniors", seniorService.getAllSeniors());

        return "all-seniors";
    }


}